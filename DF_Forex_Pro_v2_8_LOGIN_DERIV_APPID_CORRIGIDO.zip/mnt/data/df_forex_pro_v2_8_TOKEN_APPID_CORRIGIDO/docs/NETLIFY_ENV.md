# Variáveis de ambiente do Netlify — DF Forex Pro v2.3

Configure em **Netlify > Site configuration > Environment variables**.

```env
SUPABASE_URL=
SUPABASE_SERVICE_ROLE_KEY=

PUBLIC_SITE_URL=https://delicate-longma-e8f8d2.netlify.app
BROKER_CONNECTOR=deriv_api
DERIV_AUTH_MODE=legacy_oauth_or_pat
DERIV_APP_ID=SEU_APP_ID_DERIV
DERIV_LEGACY_APP_ID=SEU_APP_ID_DERIV
DERIV_API_TOKEN_DEMO=
DERIV_API_TOKEN_LIVE=
DERIV_TRADE_MODE=data_only
DERIV_ENABLE_ORDER_EXECUTION=false

BOT_MODE=dry_run
ACCOUNT_TYPE=demo
ENABLE_ORDER_EXECUTION=false
ALLOW_LIVE_TRADING=false

FOREX_SYMBOLS=frxEURUSD,frxGBPUSD,frxUSDJPY,frxAUDUSD
DEFAULT_TIMEFRAME_MINUTES=60
MAX_RISK_PER_TRADE_PCT=0.5
MAX_DAILY_LOSS_PCT=2
MAX_WEEKLY_LOSS_PCT=5
MAX_MONTHLY_DRAWDOWN_PCT=10
MIN_SIGNAL_SCORE=80
```

A `SUPABASE_SERVICE_ROLE_KEY` nunca deve ser colocada no frontend ou no GitHub.

## Deriv retorno automático

Para o site oficial:

```env
PUBLIC_SITE_URL=https://df-forex.netlify.app
DERIV_AUTH_MODE=oauth2_pkce
DERIV_OAUTH_CLIENT_ID=SEU_CLIENT_ID_DERIV
DERIV_OAUTH_REDIRECT_URI=https://df-forex.netlify.app/deriv-callback.html
DERIV_OAUTH_SCOPE=trade account_manage
```

Se usar OAuth legado, configure `DERIV_LEGACY_APP_ID` e garanta que o Website URL do app Deriv seja `https://df-forex.netlify.app/deriv-callback.html`.
